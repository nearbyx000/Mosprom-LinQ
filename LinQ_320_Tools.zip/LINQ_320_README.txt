LinQ resized model comparison scripts

Requires Python 3.12 WSL venv, installed pika, PIL, numpy,
plus PYTHONPATH pointing to the vendor/tpu_pycloud_format directory.

Extract both .py files to ~/linq-build.
For previously uploaded 640 model:
PYTHONPATH="$PWD/vendor" python linq_wsl_smoke_resized.py --side 640 --image calib/t3.jpg

ONLY AFTER the distinct 320x320 TPU model is compiled and uploaded to /auto/cache/hackathon16045/yolov8n_320.tpu:
PYTHONPATH="$PWD/vendor" python linq_wsl_smoke_resized.py --side 320 --program /auto/cache/hackathon16045/yolov8n_320.tpu --image calib/t3.jpg --out person_320.jpg
PYTHONPATH="$PWD/vendor" python linq_rtt_probe_resized.py --side 320 --program /auto/cache/hackathon16045/yolov8n_320.tpu --image calib/t3.jpg --count 5

Do not use --side 320 with the original 640x640 model.
