# SafeSight: локальный JPEG → удалённый LinQ TPU → JSON (без перекомпиляции)

Проверенная модель: `/auto/cache/hackathon16045/yolov8n.tpu` (YOLOv8n COCO 640×640).
Код адаптирован под официальный RabbitMQ-протокол LinQ. Выход облачного TPU `output0 (1,84,8400)`; NMS и person bbox вычисляются шлюзом.

## Важно: где запускать шлюз

`gateway.py` должен исполняться **на удалённой машине с быстрым доступом к RabbitMQ и TPU**, иначе тензоры всё равно пройдут через VPN. Если у вас нет отдельного SSH/VPS внутри инфраструктуры организаторов, запускайте `gateway.py` в **Jupyter Terminal** на хосте организаторов. В этом случае Jupyter Notebook не участвует в инференсе; терминал нужен только чтобы запустить Python-процесс. Закрытие сеанса/политики инфраструктуры могут завершить процесс. Перенос на отдельный сервер возможен после получения прав от организаторов.

## 1. На удалённой машине LinQ (один терминал)

Загрузить ZIP через UI файлов Jupyter; затем в Terminal:

```bash
unzip -o SafeSight_JPEG_Gateway.zip
cd SafeSight_JPEG_Gateway
python gateway.py --program /auto/cache/hackathon16045/yolov8n.tpu
```

Если Python не видит зависимости, проверить `python -c 'import pika,numpy,PIL,tpu_pycloud_format; print("OK")'`. На официальном Jupyter они использовались ранее.

Скопировать из вывода строку `GATEWAY READY | route: safesight.jpeg.<случайный токен>`; это маршрут для клиента. Не публиковать его публично.

## 2. В WSL (второй терминал)

Если `SafeSight_JPEG_Gateway.zip` лежит в `C:\Users\Xonor\Downloads`:

```bash
cd ~/linq-build
unzip -o /mnt/c/Users/Xonor/Downloads/SafeSight_JPEG_Gateway.zip
python -m pip install pika Pillow
python SafeSight_JPEG_Gateway/client.py --image calib/t3.jpg --route 'СКОПИРОВАННЫЙ_МАРШРУТ'
```

Дополнительно 3 последовательных замера:

```bash
python SafeSight_JPEG_Gateway/client.py --image calib/t3.jpg --route 'СКОПИРОВАННЫЙ_МАРШРУТ' --count 3
```

Ожидаемый результат: 4 человека для ранее проверенного `t3.jpg` (если тот же файл). Выходные файлы: `person_gateway.jpg` (рамки) и `detections_gateway.json`. Измерения: `RTT`, `publish`, `gateway`, `TPU`, JPEG/JSON байты.

## 3. Почему не отправляем JPEG напрямую в TPU?

Официальный TPU-воркер `input` ожидает `serialize(PyTask({'images': tensor}))`. Поэтому нужен промежуточный Python gateway, превращающий JPEG в float32 NCHW, и обрабатывающий массив на выходе.

## 4. Как устроено

```text
WSL / локальный FastAPI                  Удалённая среда организаторов
JPEG → AMQP tpu.direct:secret_route  →   gateway.py
                                          ↓ JPEG decode / letterbox
                                       PyTask float32 (4.9MB)
                                          ↓  локальный/внутрисетевой RabbitMQ
                                       LinQ TPU (yolov8n.tpu)
                                          ↓  output0 (2.8MB)
                                       NMS → JSON
WSL / FastAPI ← AMQP reply route      ←   компактные детекции
```

Общий доступ к RabbitMQ разрешён только в рамках хакатона. Используются временные эксклюзивные AMQP очереди и секретный случайный routing key. Потребуется возможность создавать/bind очереди к `tpu.direct`: если организаторы запретили это, попросите отдельный vhost или шлюз по разрешённому транспорту.

Ограничение для потока: gateway последовательно обрабатывает запросы; эксперимент должен показать RTT в вашей среде. Это **не** означает 30 FPS инференса. Видеопоток можно показывать 30 FPS независимо, детекции обновлять по мере поступления. Передача в Web и логика событий требуют подключения к актуальному FastAPI команды.

Не публикуйте секреты VPN/RabbitMQ и внутренний маршрут в GitHub. Не распространяйте компоненты SDK/формата без разрешения организаторов.
