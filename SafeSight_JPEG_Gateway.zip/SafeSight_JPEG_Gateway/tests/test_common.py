import io
import unittest
import numpy as np
from PIL import Image
from yolo_common import jpeg_to_tensor, person_detections


class TestCommon(unittest.TestCase):
    def test_preprocess_shape_and_range(self):
        image = Image.new('RGB', (1280, 720), (20, 80, 120))
        b = io.BytesIO()
        image.save(b, 'JPEG')
        tensor, meta = jpeg_to_tensor(b.getvalue())
        self.assertEqual(tensor.shape, (1, 3, 640, 640))
        self.assertEqual(tensor.dtype, np.float32)
        self.assertEqual(meta[:2], (1280, 720))
        self.assertGreaterEqual(float(tensor.min()), 0)
        self.assertLessEqual(float(tensor.max()), 1)

    def test_decode_and_nms(self):
        # 2 overlapping predictions of the same person become 1.
        a = np.zeros((1, 84, 8400), dtype=np.float32)
        a[0, :4, 0] = [320, 320, 100, 200]
        a[0, 4, 0] = 0.9
        a[0, :4, 1] = [321, 321, 100, 200]
        a[0, 4, 1] = 0.8
        out = person_detections(a, (640, 640, 1, 0, 0))
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]['bbox'], [270, 220, 370, 420])

    def test_invalid_non_jpeg(self):
        with self.assertRaises(ValueError):
            jpeg_to_tensor(b'not an image')


if __name__ == '__main__':
    unittest.main()
