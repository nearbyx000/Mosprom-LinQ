"""Validate gateway's non-network pipeline with synthetic TPU output.

No broker and no LinQ SDK used in this unit test.
"""
import importlib.util
from io import BytesIO
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch
import numpy as np
from PIL import Image


class TPUFake:
    def infer(self, tensor):
        assert tensor.shape == (1, 3, 640, 640)
        array = np.zeros((1, 84, 8400), dtype=np.float32)
        array[0, :4, 0] = [320, 320, 100, 200]
        array[0, 4, 0] = 0.9
        return array, {'status_code': 0, 'inference_time': 0.0044}, 1.2, 4915240, 2822479


class TestGatewayFake(unittest.TestCase):
    def test_gateway_returns_only_box_json_metadata(self):
        format_stub = types.ModuleType('tpu_pycloud_format')
        for name in ('MESSAGE_ID_ATTR_NAME', 'RESPONSE_ROUTING_KEYS_ATTR_NAME', 'TARGET_URI_ATTR_NAME'):
            setattr(format_stub, name, name)
        for name in ('PyTask', 'deserialize', 'serialize'):
            setattr(format_stub, name, lambda *a, **k: None)
        with patch.dict(sys.modules, {'pika': types.ModuleType('pika'), 'tpu_pycloud_format': format_stub}):
            spec = importlib.util.spec_from_file_location('gateway_for_test', Path(__file__).resolve().parents[1] / 'gateway.py')
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            jpeg = BytesIO()
            Image.new('RGB', (640, 640), (140, 150, 160)).save(jpeg, format='JPEG')
            response = module.handle_jpeg(jpeg.getvalue(), TPUFake(), 'f42', 0.25)
        self.assertTrue(response['ok'])
        self.assertEqual(response['frame_id'], 'f42')
        self.assertEqual(response['detections'][0]['bbox'], [270, 220, 370, 420])
        self.assertEqual(response['stats']['tpu_worker_ms'], 4.4)
        self.assertNotIn('output0', response)
        self.assertNotIn('tensor', response)


if __name__ == '__main__':
    unittest.main()
